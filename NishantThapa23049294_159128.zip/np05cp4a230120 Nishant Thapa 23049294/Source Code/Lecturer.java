/**
 * This is the Lecturer Class which is used to store the information of lecturer.
 * @author Nishant Thapa
 * Collage ID: np05cp4a230120
 *  @version 2.0
 */

public class Lecturer extends Teacher
{   //Declaration of the instance variables in lecturer class.
     private String department;
     private int yearOfExperience;
     private int gradedScore;
     private boolean hasGraded;
     
     
      /**Creating a Constructor
      */
     public Lecturer(String name, int teacherID,String address,String workingType,String status, String department, int yearOfExperience, int workingHours)
     {    
         super(name,teacherID,address,workingType,status);
         super.setWorkingHours(workingHours);
         this.department=department;
         this.yearOfExperience=yearOfExperience;
         this.gradedScore=0;
         this.hasGraded=false;
    
     }

    
       /** Using accessor methods (get method) to retrive the value of department.
       * 
       */    
     public String getDepartment()
     {
            return department;
     }
     
     
     
       /** Using accessor methods (get method) to retrive the value of yearOfExperience.
       * 
       */
     public int getYearsOfExperience()
     {
            return yearOfExperience;
     }
     
     
     
       /** Using accessor methods (get method) to retrive the value of gradedScore.
       * 
       */
     public int getGradeScore()
     {
           return gradedScore;
     }
     
     
     
       /** Using accessor methods (get method) to retrive the value of hasGraded.
       * 
       */
     public boolean getHasGraded()
     {
          return hasGraded;
     }

    
       /**Using set method to set a new value through a parameter
         * 
         */    
     public void setGradedScore(int gradedScore)
     {
         this.gradedScore=gradedScore;
     }

      /**
       * This method helps to grade the assignment according to the grade recevied
       */
     public void gradeAssignment(int gradedScore, String department ,int yearOfExperience ) 
     {
       
        /**Checking if the assignment has not been graded yet and the lecturer meets the criteria and using "equals method" to check the equility of two Strings
        * 
        */
        if ( yearOfExperience>= 5 && this.department.equals(department)){
        
        
            if (gradedScore >= 70) 
    
            {
             System.out.println("Grade: A");
            } 
            
            else if ( gradedScore >= 60) 
            {
             System.out.println("Grade: B");
            } 
            else if ( gradedScore>= 50) 
            {
            System.out.println("Grade: C");
            } 
            else if ( gradedScore >= 40) 
            {
             System.out.println("Grade: D");
            } 
            else if ( gradedScore<40)
            {
             System.out.println("Grade: E");
            }

       
           this.gradedScore = gradedScore;
           hasGraded=true;

       
        }
        
        else{
            System.out.println("Assignment has not been graded !!!");
        }
      

     }
    
        /**method to display the lecturer.
        * 
        */
      public void displayLecturer()
      {
        super.Display();
        System.out.println(department);
        System.out.println(yearOfExperience);
      }
}