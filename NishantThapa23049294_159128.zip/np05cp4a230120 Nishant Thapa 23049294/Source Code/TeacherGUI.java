/**
 * This is the TeacherGUI Class 
 * @author Nishant Thapa
 * Collage ID: np05cp4a230120
 *  @version 1.0
 */
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import java.util.ArrayList;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Component;

public class TeacherGUI {

    private JFrame frame;
    private JPanel panel, lecturerPanel, tutorPanel, assignmentPanel;
    private JButton lecturerBtn, gradeAssignmentBtn, tutorBtn, addingLecturer, displayBtn, lClearBtn, addingTutor,
            removeTutorBtn, tutorDisplayBtn, tutorClearBtn, salaryTutorBtn, gradeBtn, assignmentDisplayBtn,
            assignmentClearBtn;
    private JLabel lecturerLabel, lecturerNamelbl, teacherIdlbl, addresslbl, workingTypelbl, statuslbl, departmentlbl,
            yearOfExplbl, hourslbl, tutorLabel, tutorNamelbl, tutorIdlbl, tutorAddresslbl, tutorWorkingTypelbl,
            tutorStatuslbl, tutorSalarylbl, tutorSpecializationlbl, tutorHourslbl, tutorAcademiclbl,
            performanceIndexlbl, gradelbl, grdTeacherIdlbl, gradedScorelbl, assignmentDeprtlbl, assignmentYearOfExplbl;
    private JTabbedPane tab;
    private JTextField nameTxt, teacherIdTxt, addressTxt, workingTypeTxt, statusTxt, lecturer_departmentTxt, yearOfExpTxt,
            hoursTxt,tutorNameTxt, tutorIdTxt, tutorAddressTxt, tutorWorkingTypeTxt, tutorStatusTxt, tutorSalaryTxt,
            tutorSpecializationTxt, tutorHoursTxt, tutorAcademicTxt, performaceIndexTxt,grdTeacherIdTxt, gradedScoreTxt, assignmentDepartmentTxt, assignmentYearOfExpTxt;

    private ArrayList<Teacher> teachersList = new ArrayList<>();

    public TeacherGUI() {

        frame = new JFrame("Teacher Management System");
        frame.setSize(1000, 600);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);

        panel = new JPanel();
        panel.setBounds(0, 0, 250, 600);
        panel.setBackground(Color.DARK_GRAY);
        panel.setLayout(null);

        lecturerBtn = new JButton("Manage Lecturer");
        lecturerBtn.setBounds(30, 200, 200, 50);
        panel.add(lecturerBtn);

        tutorBtn = new JButton("Manage Tutor");
        tutorBtn.setBounds(30, 260, 200, 50);
        panel.add(tutorBtn);

        gradeAssignmentBtn = new JButton("Grade Assignment");
        gradeAssignmentBtn.setBounds(30, 320, 200, 50);
        panel.add(gradeAssignmentBtn);
        frame.add(panel);

        tab = new JTabbedPane();
        tab.setBounds(250, -30, 750, 600);
        frame.add(tab);

        lecturerPanel = new JPanel();
        lecturerPanel.setLayout(null);
        lecturerPanel.setBounds(270, -30, 750, 600);
        lecturerPanel.setBackground(Color.GRAY);
        tab.add(lecturerPanel);

        lecturerLabel = new JLabel("Manage Lecturer");
        lecturerLabel.setBounds(250, 40, 250, 50);
        Font lecturerFont = new Font(Font.SANS_SERIF, Font.BOLD, 30);
        lecturerLabel.setFont(lecturerFont);
        lecturerPanel.add(lecturerLabel);

        Font font = new Font(Font.SANS_SERIF, Font.BOLD, 14);

        lecturerNamelbl = new JLabel("Name");
        lecturerNamelbl.setFont(font);
        lecturerNamelbl.setBounds(100, 110, 150, 30);
        nameTxt = new JTextField();
        nameTxt.setBounds(100, 140, 150, 25);
        lecturerPanel.add(lecturerNamelbl);
        lecturerPanel.add(nameTxt);

        teacherIdlbl = new JLabel("Teacher ID");
        teacherIdlbl.setFont(font);
        teacherIdlbl.setBounds(100, 180, 150, 30);
        teacherIdTxt = new JTextField();
        teacherIdTxt.setBounds(100, 210, 150, 25);
        lecturerPanel.add(teacherIdlbl);
        lecturerPanel.add(teacherIdTxt);

        addresslbl = new JLabel("Address");
        addresslbl.setFont(font);
        addresslbl.setBounds(100, 250, 150, 30);
        addressTxt = new JTextField();
        addressTxt.setBounds(100, 280, 150, 25);
        lecturerPanel.add(addresslbl);
        lecturerPanel.add(addressTxt);

        workingTypelbl = new JLabel("Working Type");
        workingTypelbl.setFont(font);
        workingTypelbl.setBounds(100, 320, 150, 30);
        workingTypeTxt = new JTextField();
        workingTypeTxt.setBounds(100, 350, 150, 25);
        lecturerPanel.add(workingTypelbl);
        lecturerPanel.add(workingTypeTxt);

        statuslbl = new JLabel("Status");
        statuslbl.setFont(font);
        statuslbl.setBounds(450, 320, 150, 30);
        statusTxt = new JTextField();
        statusTxt.setBounds(450, 350, 150, 25);
        lecturerPanel.add(statuslbl);
        lecturerPanel.add(statusTxt);

        departmentlbl = new JLabel("Department");
        departmentlbl.setFont(font);
        departmentlbl.setBounds(450, 110, 150, 30);
        lecturer_departmentTxt = new JTextField();
        lecturer_departmentTxt.setBounds(450, 140, 150, 25);
        lecturerPanel.add(departmentlbl);
        lecturerPanel.add(lecturer_departmentTxt);

        yearOfExplbl = new JLabel("Year of experience");
        yearOfExplbl.setFont(font);
        yearOfExplbl.setBounds(450, 180, 150, 30);
        yearOfExpTxt = new JTextField();
        yearOfExpTxt.setBounds(450, 210, 150, 25);
        lecturerPanel.add(yearOfExplbl);
        lecturerPanel.add(yearOfExpTxt);

        hourslbl = new JLabel("Working Hours");
        hourslbl.setFont(font);
        hourslbl.setBounds(450, 250, 150, 30);
        hoursTxt = new JTextField();
        hoursTxt.setBounds(450, 280, 150, 25);
        lecturerPanel.add(hoursTxt);
        lecturerPanel.add(hourslbl);

        addingLecturer = new JButton("Add Lecturer");
        addingLecturer.setBounds(150, 450, 120, 40);
        lecturerPanel.add(addingLecturer);

        addingLecturer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                addLecturer();
            }
        });

        displayBtn = new JButton("Display");
        displayBtn.setBounds(300, 450, 120, 40);
        lecturerPanel.add(displayBtn);

        displayBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                lecturerDisplay();
            }
        });

        lClearBtn = new JButton("Clear");
        lClearBtn.setBounds(450, 450, 150, 40);
        lecturerPanel.add(lClearBtn);
        lClearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                clearFields(lecturerPanel);
            }
        });

        tutorPanel = new JPanel();
        tutorPanel.setLayout(null);
        tutorPanel.setBounds(250, -30, 750, 600);
        tutorPanel.setBackground(Color.gray);
        tab.add(tutorPanel);

        tutorLabel = new JLabel("Manage Tutor");
        tutorLabel.setBounds(250, 40, 250, 50);
        Font tutorFont = new Font(Font.SANS_SERIF, Font.BOLD, 30);
        tutorLabel.setFont(tutorFont);
        tutorPanel.add(tutorLabel);

        tutorNamelbl = new JLabel("Name");
        tutorNamelbl.setFont(font);
        tutorNamelbl.setBounds(100, 110, 150, 30);
        tutorNameTxt = new JTextField();
        tutorNameTxt.setBounds(100, 140, 150, 25);
        tutorPanel.add(tutorNamelbl);
        tutorPanel.add(tutorNameTxt);

        tutorIdlbl = new JLabel("Teacher ID");
        tutorIdlbl.setFont(font);
        tutorIdlbl.setBounds(100, 180, 150, 30);
        tutorIdTxt = new JTextField();
        tutorIdTxt.setBounds(100, 210, 150, 25);
        tutorPanel.add(tutorIdlbl);
        tutorPanel.add(tutorIdTxt);

        tutorAddresslbl = new JLabel("Address");
        tutorAddresslbl.setFont(font);
        tutorAddresslbl.setBounds(100, 250, 150, 30);
        tutorAddressTxt = new JTextField();
        tutorAddressTxt.setBounds(100, 280, 150, 25);
        tutorPanel.add(tutorAddresslbl);
        tutorPanel.add(tutorAddressTxt);

        tutorWorkingTypelbl = new JLabel("Working Type");
        tutorWorkingTypelbl.setFont(font);
        tutorWorkingTypelbl.setBounds(100, 320, 150, 30);
        tutorWorkingTypeTxt = new JTextField();
        tutorWorkingTypeTxt.setBounds(100, 350, 150, 25);
        tutorPanel.add(tutorWorkingTypelbl);
        tutorPanel.add(tutorWorkingTypeTxt);

        tutorStatuslbl = new JLabel("Status");
        tutorStatuslbl.setFont(font);
        tutorStatuslbl.setBounds(450, 320, 150, 30);
        tutorStatusTxt = new JTextField();
        tutorStatusTxt.setBounds(450, 350, 150, 25);
        tutorPanel.add(tutorStatuslbl);
        tutorPanel.add(tutorStatusTxt);

        tutorSalarylbl = new JLabel("Salary");
        tutorSalarylbl.setFont(font);
        tutorSalarylbl.setBounds(450, 110, 150, 30);
        tutorSalaryTxt = new JTextField();
        tutorSalaryTxt.setBounds(450, 140, 150, 25);
        tutorPanel.add(tutorSalaryTxt);
        tutorPanel.add(tutorSalarylbl);

        tutorSpecializationlbl = new JLabel("Specialization");
        tutorSpecializationlbl.setFont(font);
        tutorSpecializationlbl.setBounds(450, 180, 150, 30);
        tutorSpecializationTxt = new JTextField();
        tutorSpecializationTxt.setBounds(450, 210, 150, 25);
        tutorPanel.add(tutorSpecializationlbl);
        tutorPanel.add(tutorSpecializationTxt);

        tutorHourslbl = new JLabel("Working Hours");
        tutorHourslbl.setFont(font);
        tutorHourslbl.setBounds(450, 250, 150, 30);
        tutorHoursTxt = new JTextField();
        tutorHoursTxt.setBounds(450, 280, 150, 25);
        tutorPanel.add(tutorHoursTxt);
        tutorPanel.add(tutorHourslbl);

        tutorAcademiclbl = new JLabel("Academic Qualification");
        tutorAcademiclbl.setFont(font);
        tutorAcademiclbl.setBounds(100, 390, 180, 30);
        tutorAcademicTxt = new JTextField();
        tutorAcademicTxt.setBounds(100, 420, 150, 25);
        tutorPanel.add(tutorAcademiclbl);
        tutorPanel.add(tutorAcademicTxt);

        performanceIndexlbl = new JLabel("Performace Index");
        performanceIndexlbl.setFont(font);
        performanceIndexlbl.setBounds(450, 390, 150, 30);
        performaceIndexTxt = new JTextField();
        performaceIndexTxt.setBounds(450, 420, 150, 25);
        tutorPanel.add(performanceIndexlbl);
        tutorPanel.add(performaceIndexTxt);

        addingTutor = new JButton("Add Tutor");
        addingTutor.setBounds(80, 500, 100, 40);
        tutorPanel.add(addingTutor);

        addingTutor.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                addTutor();
            }
        });

        tutorDisplayBtn = new JButton("Display");
        tutorDisplayBtn.setBounds(190, 500, 100, 40);
        tutorPanel.add(tutorDisplayBtn);

        tutorDisplayBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                tutorDisplay();
            }

        });

        tutorClearBtn = new JButton("Clear");
        tutorClearBtn.setBounds(300, 500, 100, 40);
        tutorPanel.add(tutorClearBtn);
        tutorClearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                clearFields(tutorPanel);
            }

        });

        removeTutorBtn = new JButton("Remove");
        removeTutorBtn.setBounds(410, 500, 100, 40);
        tutorPanel.add(removeTutorBtn);

        removeTutorBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                removeTutor();

            }

        });

        salaryTutorBtn = new JButton("Set Salary");
        salaryTutorBtn.setBounds(520, 500, 100, 40);
        tutorPanel.add(salaryTutorBtn);

        salaryTutorBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                setupSalary();
            }
        });

        assignmentPanel = new JPanel();
        assignmentPanel.setLayout(null);
        assignmentPanel.setBounds(270, -30, 750, 600);
        assignmentPanel.setBackground(Color.GRAY);
        tab.add(assignmentPanel);

        gradelbl = new JLabel("Assignment Grading");
        gradelbl.setBounds(200, 80, 350, 50);
        Font gradingFont = new Font(Font.SANS_SERIF, Font.BOLD, 30);
        gradelbl.setFont(gradingFont);
        assignmentPanel.add(gradelbl);

        grdTeacherIdlbl = new JLabel("Teacher ID");
        grdTeacherIdlbl.setFont(font);
        grdTeacherIdlbl.setBounds(100, 180, 150, 30);
        grdTeacherIdTxt = new JTextField();
        grdTeacherIdTxt.setBounds(100, 210, 150, 25);
        assignmentPanel.add(grdTeacherIdlbl);
        assignmentPanel.add(grdTeacherIdTxt);

        gradedScorelbl = new JLabel("Graded Score");
        gradedScorelbl.setFont(font);
        gradedScorelbl.setBounds(400, 180, 150, 30);
        gradedScoreTxt = new JTextField();
        gradedScoreTxt.setBounds(400, 210, 150, 25);
        assignmentPanel.add(gradedScorelbl);
        assignmentPanel.add(gradedScoreTxt);

        assignmentDeprtlbl = new JLabel("Department");
        assignmentDeprtlbl.setFont(font);
        assignmentDeprtlbl.setBounds(100, 250, 150, 30);
        assignmentDepartmentTxt = new JTextField();
        assignmentDepartmentTxt.setBounds(100, 280, 150, 25);
        assignmentPanel.add(assignmentDepartmentTxt);
        assignmentPanel.add(assignmentDeprtlbl);

        assignmentYearOfExplbl = new JLabel("Year Of Experience");
        assignmentYearOfExplbl.setFont(font);
        assignmentYearOfExplbl.setBounds(400, 250, 150, 30);
        assignmentYearOfExpTxt = new JTextField();
        assignmentYearOfExpTxt.setBounds(400, 280, 150, 25);
        assignmentPanel.add(assignmentYearOfExpTxt);
        assignmentPanel.add(assignmentYearOfExplbl);

        gradeBtn = new JButton("Grade");
        gradeBtn.setBounds(120, 350, 120, 40);
        assignmentPanel.add(gradeBtn);

        gradeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                grade_Assignment();
            }
        });

        assignmentDisplayBtn = new JButton("Display");
        assignmentDisplayBtn.setBounds(270, 350, 120, 40);
        assignmentPanel.add(assignmentDisplayBtn);

        assignmentDisplayBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                assignmentDisplay();
            }
        });

        assignmentClearBtn = new JButton("Clear");
        assignmentClearBtn.setBounds(420, 350, 150, 40);
        assignmentPanel.add(assignmentClearBtn);

        assignmentClearBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                clearFields(lecturerPanel);
            }
        });

        frame.setLayout(null);
        frame.setVisible(true);

        // Button that switches to Lecturer Management Panel
        lecturerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tab.setSelectedComponent(lecturerPanel);
            }
        });

        // Button that switches to Tutor Management Panel
        tutorBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tab.setSelectedComponent(tutorPanel);
            }
        });

        // Button that switches to Grade Assignment Manage Panel
        gradeAssignmentBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tab.setSelectedComponent(assignmentPanel);
            }
        });

    }

    // Method that returns input data collected by displayTxt .
    private String teacherFields(Teacher teacher) {
        String displayTxt = "";
        displayTxt += "ID: " + teacher.getTeacherID() + "\n";
        displayTxt += "Name : " + teacher.getName() + "\n";
        displayTxt += "Address : " + teacher.getAddress() + "\n";
        displayTxt += "Working Type : " + teacher.getWorkingType() + "\n";
        displayTxt += "Status : " + teacher.getStatus() + "\n";

        return displayTxt;
    }

    // Method that helps to check the existing Teacher ID and used for validation.
    private boolean isInTeachersLIst(int give_teacherID) {
        for (Teacher teacher_obj : teachersList) {
            if (teacher_obj.getTeacherID() == give_teacherID) {
                return true;
            }
        }
        return false;
    }

    // Method that adds Lecturer Objects into the ArrayList
    private void addLecturer() {

        /* Here, we have made a call to the method that checks whether the JTextField of given panel is empty or not */

        boolean islecturerTextFieldEmpty = isTextFieldEmpty(lecturerPanel);

        if ( islecturerTextFieldEmpty) {
            JOptionPane.showMessageDialog(frame, "Please fill all the fields", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int intID = Integer.parseInt(teacherIdTxt.getText().trim());
            int intExp = Integer.parseInt(yearOfExpTxt.getText().trim());
            int intHour = Integer.parseInt(hoursTxt.getText().trim());
            

            /* Checking the negativity of input numbers */
            if (intID > 0 && intExp > 0 && intHour > 0) {

                // Here we have done the validation of teacherID
                if (isInTeachersLIst(intID)) {
                    JOptionPane.showMessageDialog(frame, "Teacher ID " + intID + " is already exist.", "Error Message",
                            JOptionPane.ERROR_MESSAGE);
                }
                // If the given teacherID is not found in the ArrayList, simply executing the
                // below "else" code that adds to the ArrayList.
                else {
                    Teacher lecturer = new Lecturer(nameTxt.getText().trim(), intID, addressTxt.getText().trim(),
                            workingTypeTxt.getText().trim(), statusTxt.getText().trim(),
                            lecturer_departmentTxt.getText().trim(), intExp, intHour);

                    int option = JOptionPane.showConfirmDialog(frame, "Are you sure want to Add Lecturer?",
                            "Confirmation",
                            JOptionPane.YES_NO_OPTION);
                    if (option == JOptionPane.YES_OPTION) {
                        teachersList.add(lecturer);
                        JOptionPane.showMessageDialog(frame, "Lecturer added successfully !", "Successful Message",
                                JOptionPane.INFORMATION_MESSAGE);

                    } else {
                        JOptionPane.showMessageDialog(frame, "Cancelled successful", "Information",
                                JOptionPane.INFORMATION_MESSAGE);
                    }

                }

                /* If negative value found , suitable message for the cause for the error */
            } else if (intID < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter teacherId in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else if (intExp < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter Year Of experience in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else if (intHour < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter Working Hours in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException ne)

        {
            JOptionPane.showMessageDialog(frame,
                    "TeacherID , Year of experience and Working Hours must be numeric !", "Error",
                    JOptionPane.ERROR_MESSAGE);

        }
    }

    // Method that adds Tutor Objects into the ArrayList
    private void addTutor() {

        // Here, we have made a call to the method that checks whether the JTextField of
        // given panel is empty or not .
        boolean tutorTextField = isTextFieldEmpty(tutorPanel);

        if (tutorTextField) {
            JOptionPane.showMessageDialog(frame, "Please fill all the fields", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int intTutorId = Integer.parseInt(tutorIdTxt.getText().trim());
            int intTutorWorkingHour = Integer.parseInt(tutorHoursTxt.getText().trim());
            double tutorSalary = Double.parseDouble(tutorSalaryTxt.getText().trim());
            int performanceIndex = Integer.parseInt(performaceIndexTxt.getText().trim());

            /* Checking the negativity of input numbers */
            if (intTutorId > 0 && intTutorWorkingHour > 0 && tutorSalary > 0 && performanceIndex > 0) {

                // Here we have done the validation of teacherID
                if (isInTeachersLIst(intTutorId)) {
                    JOptionPane.showMessageDialog(frame, "Teacher ID " + intTutorId + " is already exist.",
                            "Error Message", JOptionPane.ERROR_MESSAGE);
                }

                // If the given teacherID is not found in the ArrayList, simply executing the
                // below "else" code that adds to the ArrayList.
                else {
                    if (performanceIndex >= 5 && performanceIndex <= 10) {
                        Teacher tutor = new Tutor(tutorNameTxt.getText().trim(), intTutorId,
                                tutorAddressTxt.getText().trim(), tutorWorkingTypeTxt.getText().trim(),
                                tutorStatusTxt.getText().trim(), intTutorWorkingHour, tutorSalary,
                                tutorSpecializationTxt.getText().trim(),
                                tutorAcademicTxt.getText().trim(), performanceIndex);

                        int option = JOptionPane.showConfirmDialog(frame, "Are you sure want to Add Tutor?",
                                "Confirmation",
                                JOptionPane.YES_NO_OPTION);
                        if (option == JOptionPane.YES_OPTION) {
                            teachersList.add(tutor);

                            JOptionPane.showMessageDialog(frame, "Tutor added successfully !", "Successful Message",
                                    JOptionPane.INFORMATION_MESSAGE);

                        } else {
                            JOptionPane.showMessageDialog(frame, "Cancelled successful", "Information",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }

                    } else {
                        JOptionPane.showMessageDialog(frame, "PerformaceIndex must be between 5 to 10", "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }

            } else if (intTutorId < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter teacherId in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else if (intTutorWorkingHour < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter Working Hours in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else if (tutorSalary < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter Salary in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else if (performanceIndex < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter Performance Index in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }

        }
        /**
         * If the input for Teacher ID, Working Hours, Performance Index, or Salary is
         * not numeric,
         * NumberFormatException will be thrown.
         */
        catch (NumberFormatException ne) {
            JOptionPane.showMessageDialog(frame,
                    "Teacher ID , Working Hours , Performance Index and Salary must be in numeric !",
                    "Error", JOptionPane.ERROR_MESSAGE);

        }
    }

    /**
     * Method that displays the input data into the terminal as well as dialog box.
     */
    private void lecturerDisplay() {
        String displayTxt = "";
        for (Teacher lectuererDisplay : teachersList) {
            if (lectuererDisplay instanceof Lecturer) {
                /* calling to the method that retruns the displayTxt of Lecturer. */
                displayTxt += teacherFields(lectuererDisplay);
                /**
                 * Down Casting lecturerDisplay to Lecturer Object to call the method of the
                 * Lecturer Class
                 */
                displayTxt += "Year of Experience : " + ((Lecturer) lectuererDisplay).getYearsOfExperience() + "\n";
                displayTxt += "working Hours : " + ((Lecturer) lectuererDisplay).getworkingHours() + "\n";
                displayTxt += "Department : " + ((Lecturer) lectuererDisplay).getDepartment() + "\n";

                /*
                 * Here we have call the method of lecturer Class , which display the data into
                 * the terminal
                 * 
                 */
                lectuererDisplay.Display();

            }
        }
        if (displayTxt.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill the information to display .", "Error Messange",
                    JOptionPane.ERROR_MESSAGE);

        } else {
            /** Adding the String data "displaytxt" into the dialog box */
            JOptionPane.showMessageDialog(frame, displayTxt, "Information Message",
                    JOptionPane.INFORMATION_MESSAGE);

        }

    }

    /**
     * Method that displays the input data into the terminal as well as dialog box.
     */
    private void tutorDisplay() {
        String displayTxt = "";
        for (Teacher tutorDisplay : teachersList) {
            if (tutorDisplay instanceof Tutor) {
                /** calling to the method that retruns the displayTxt of Tutor. */
                displayTxt += teacherFields(tutorDisplay);
                /**
                 * Down Casting tutorDisplay to Tutor Object to call the method of the Tutor
                 * Class
                 *
                 */
                displayTxt += "Academic Qualificatation : " + ((Tutor) tutorDisplay).getAcademicQualification() + "\n";
                displayTxt += "Salary : " + ((Tutor) tutorDisplay).getsalary() + "\n";
                displayTxt += "Specialization: " + ((Tutor) tutorDisplay).getspecialization() + "\n";
                displayTxt += "working Hours : " + ((Tutor) tutorDisplay).getworkingHours() + "\n";
                displayTxt += "Performance Index: " + ((Tutor) tutorDisplay).getPerformance() + "\n" + "\n";

                /*
                 * Here we have call the Display method of Tutor Class , which display the data
                 * into the terminal
                 *
                 */
                tutorDisplay.Display();

            }
        }
        if (displayTxt.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill the information to display .", "Error Messange",
                    JOptionPane.ERROR_MESSAGE);

        } else {
            /** Adding the String data "displaytxt" into the dialog box */
            JOptionPane.showMessageDialog(frame, displayTxt, "Information Message",
                    JOptionPane.INFORMATION_MESSAGE);

        }
    }

    /**
     * Method that displays the input data into the terminal as well as dialog box.
     */
    private void assignmentDisplay() {
        String displayTxt = "";
        for (Teacher lectuererDisplay : teachersList) {
            if (lectuererDisplay instanceof Lecturer) {
                /**
                 * Down Casting lecturerDisplay to Lecturer Object to call the method of the
                 * Lecturer Class
                 */
                displayTxt += "Lecturer ID" + ((Lecturer) lectuererDisplay).getTeacherID() + "\n";
                displayTxt += "Department : " + ((Lecturer) lectuererDisplay).getDepartment() + "\n";
                displayTxt += "Grade Score : " + ((Lecturer) lectuererDisplay).getGradeScore() + "\n";

                /*
                 * Here we have call the method of lecturer Class , which display the data into
                 * the terminal
                 *
                 */
                lectuererDisplay.Display();
            }
        }
        if (displayTxt.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Invalid Input ", "Error Message",
                    JOptionPane.ERROR_MESSAGE);

        } else {
            JOptionPane.showMessageDialog(frame, displayTxt, "Information Message",
                    JOptionPane.INFORMATION_MESSAGE);

        }

    }

    /* Method that clear JTextField of the given JPanel */
    private void clearFields(JPanel panelling) {
        Component[] components = panelling.getComponents();
        for (Component component : components) {
            if (component instanceof JTextField) {
                ((JTextField) component).setText("");
            }
        }
    }

    /* Method that check whether the JTextField is empty or not. */
    private boolean isTextFieldEmpty(JPanel textPanelling) {
        Component[] textComponents = textPanelling.getComponents();
        for (Component textComponent : textComponents) {
            if (textComponent instanceof JTextField) {
                String text = ((JTextField) textComponent).getText().trim();
                if (text.isEmpty()) {
                    return true;
                }
            }
        }
        return false;
    }

    /* Method for removing tutor */
    private void removeTutor() {
        String teacherID1 = tutorIdTxt.getText().trim();
        if (teacherID1.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter Teacher ID you want to remove", "error messange",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            int tutorID1 = Integer.parseInt(teacherID1);

            for (Teacher tut : teachersList) {
                if (tut instanceof Tutor) {
                    if (tut.getTeacherID() == tutorID1) {

                        if (((Tutor) tut).getIsCertified()) {
                            JOptionPane.showMessageDialog(frame, "A certified tutor cannot be removed! ",
                                    "Error Message",
                                    JOptionPane.ERROR_MESSAGE);
                            return;
                        } else {
                            /*
                             * Downcasting "tut" into Tutor Object inorder to call the method form the Tutor class
                             */

                            ((Tutor) tut).removeTutor();
                            JOptionPane.showMessageDialog(frame, "Tutor removed Successfully", "Information Message",
                                    JOptionPane.INFORMATION_MESSAGE);
                            return;
                        }

                    } else {
                        JOptionPane.showMessageDialog(frame, "Invalid teacherID", "Error", JOptionPane.ERROR_MESSAGE);
                      
                    }
                }

            }
        }
        /**
         * If the input for Teacher ID is not numeric, NumberFormatException will be
         * thrown.
         * 
         */
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(frame, "Please enter TeacherID in number format", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /* Method that set the salary of Tutor */
    private void setupSalary() {
        String teacherId = tutorIdTxt.getText().trim();
        String salary = tutorSalaryTxt.getText().trim();
        String performanceIndex = performaceIndexTxt.getText().trim();

        if (teacherId.isEmpty() || salary.isEmpty() || performanceIndex.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please enter Teacher ID , salary and performanceIndex ",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int teacherID_X = Integer.parseInt(teacherId);
            double newSalary = Double.parseDouble(salary);
            int newPerformanceIndex = Integer.parseInt(performanceIndex);

            for (Teacher t : teachersList) {
                if (t instanceof Tutor) {
                    if (t.getTeacherID() == teacherID_X) {
                        if (newPerformanceIndex >= 5 && newPerformanceIndex <= 10) {
                            ((Tutor) t).setSalary(newSalary, newPerformanceIndex);
                            JOptionPane.showMessageDialog(frame, "Salary set successfully ! ", "Successful Message",
                                    JOptionPane.INFORMATION_MESSAGE);
                            return;
                        } else {
                            JOptionPane.showMessageDialog(frame, "PerformanceIndex must between 5 to 10 ",
                                    "Error Message",
                                    JOptionPane.ERROR_MESSAGE);
                                    return;
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, "Please enter correct TeacherID", "Error Message",
                                JOptionPane.ERROR_MESSAGE);
                                return;
                    }
                }
            }
        }
        /**
         * If the input for Teacher ID ,Performance Index and Salary are not numeric,NumberFormatException will be thrown.
         */
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(frame, "Teacher ID , PerformaceIndex and Salary must be Number",
                    "Error Message", JOptionPane.ERROR_MESSAGE);

        }

    }

    /* Method that grade the assignment */
    private void grade_Assignment() {
        /*
         * Here we have called the method that checks whether the JTextFields of the given panel is empty or not
         */
        boolean gradeAssignmentTextField = isTextFieldEmpty(assignmentPanel);
        if (gradeAssignmentTextField) {
            JOptionPane.showMessageDialog(frame, "Please fill all the fields", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String department = assignmentDepartmentTxt.getText().trim();
            int teacherIDInt = Integer.parseInt(grdTeacherIdTxt.getText().trim());
            int gradedScoreInt = Integer.parseInt(gradedScoreTxt.getText().trim());
            int yearsOfExperienceInt = Integer.parseInt(assignmentYearOfExpTxt.getText().trim());

            /* Checking the negativity of input numbers */
            if (teacherIDInt > 0 && gradedScoreInt > 0 && yearsOfExperienceInt > 0) {
                // Find teacher with matching ID
                Teacher teacher = null;
                for (Teacher t : teachersList) {
                    if (t.getTeacherID() == teacherIDInt) {
                        teacher = t;
                        break;
                    }
                }
                // In case of not found
                if (teacher == null) {
                    JOptionPane.showMessageDialog(frame, "Teacher with ID " + teacherIDInt + " not found", "Error",
                            JOptionPane.ERROR_MESSAGE);

                    return;
                }

                // Checking if teacher is a lecturer
                if (teacher instanceof Lecturer) {
                    if (department.equals(lecturer_departmentTxt.getText().trim()) && (yearsOfExperienceInt > 5)) {

                        int option = JOptionPane.showConfirmDialog(frame, "Are you sure want to grade the assignment?",
                                "Confirmation",
                                JOptionPane.YES_NO_OPTION);
                        if (option == JOptionPane.YES_OPTION) {
                            /*
                             * Downcasting teacher into the object of Lecturer inorder to call the gradeAssignment method
                             */
                            ((Lecturer) teacher).gradeAssignment(gradedScoreInt, department, yearsOfExperienceInt);
                            JOptionPane.showMessageDialog(frame, "Assignment graded successfully", "Success",
                                    JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(frame, "Cancelled successful", "Information",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                    } else if (!(department.equals(lecturer_departmentTxt.getText().trim()))) {
                        JOptionPane.showMessageDialog(frame, "Invalid department ! ",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    } else if (!(yearsOfExperienceInt > 5)) {
                        JOptionPane.showMessageDialog(frame, "Must have more than 5 years of Experience .",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Teacher with ID " + teacherIDInt + " is not a lecturer",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }

            } else if (teacherIDInt < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter teacherId in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else if (gradedScoreInt < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter gradedscore in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            } else if (yearsOfExperienceInt < 0) {
                JOptionPane.showMessageDialog(frame, "Please enter Year Of Experience in positive formate", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }

        }
        /**
         * If the input for Teacher ID ,graded score and year of experience are not
         * numeric, NumberFormatException will be thrown.
         * 
         */
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid input format", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /*
     * Main Method creates the instance of the TeacherGUI, which call its
     * constructor
     */
    public static void main(String[] args) {
        new TeacherGUI();
    }
}
