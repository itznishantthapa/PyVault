
/**
 * This is the Teacher Class which is used to store the information of teacher.
 * @author Nishant Thapa
 * Collage ID: np05cp4a230120
 *  @version 2.0
 */





 public class Teacher
     { 
         //Declaration of the instance variables.
      private String name;
      private int teacherID;
      private String address;
      private String workingType;
      private String status;
      private int workingHours;
     
      /**Creating a Constructor
      */
      public Teacher(String name, int teacherID,String address,String workingType,String status)
          {
           this.name=name;
           this.teacherID=teacherID;
           this.address=address;
           this.workingType=workingType;
           this.status=status;
          }

       /** Using accessor methods (get method) to retrive the value of name.
       * 
       */
    
      public String getName()
          {
            return name;
          }
          
          
       /** Using accessor methods (get method) to retrive the value of teacherID.
       * 
       */
      public int getTeacherID()
          {
            return teacherID;
          }
          
          
          
       /** Using accessor methods (get method) to retrive the value of address.
       * 
       */
      public String getAddress()
         {
            return address;
         }
         
         
         
       /** Using accessor methods (get method) to retrive the value of workingType .
       * 
       */
      public String getWorkingType()
          {
           return workingType;
          }
          
          
          
            /** Using accessor methods (get method) to retrive the value of status.
       * 
       */
      public String getStatus()
          {
           return status;
          }
          
          
          
       /** Using accessor methods (get method) to retrive the value of workingHours.
       * 
       */
      public int getworkingHours()
          {
           return workingHours;
          }
          
          

        /**Using set method to set a new value through a parameter
         * 
         */
      public void setWorkingHours(int workingHours)
          {
           this.workingHours=workingHours;
          }
          
          

       /**Displaying the outputs
        * 
        */
      public void Display()
          {
           System.out.println("The teacher name is "+ name);
           System.out.println("The teacherID is "+ teacherID);
           System.out.println("The teacher address is " + address);
           System.out.println("The teacher working-type is "+workingType);
           System.out.println("The teacher status is "+status);
        

             /**If the workingHours is not equals to 0, the workingHours will be assigned .Otherwise,"Working Hours not assigned yet." will be displayed .
              * 
              */
               if(workingHours!=0){
                   
                    System.out.println("The teacher have done "+workingHours+" hours of work.");
         
                   }
             
               else{
    
                   System.out.println("Working Hours not assigned yet.");
                  }

          }

}