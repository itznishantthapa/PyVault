
/**
 * This is the Tutor Class which is used to store the information of tutor.
 * @author Nishant Thapa
 * Collage ID: np05cp4a230120
 *  @version 2.0
 */

public class Tutor extends Teacher
{   //Declaration of instance variables in tutor class. 
    private double     salary;
    private String     specialization;
    private String     academicQualification;
    private int        performanceIndex;
    private boolean    isCertified;

    public Tutor(String name, int teacherID,String address,String workingType,String status,int workingHours, double salary, String specialization, 
    String academicQualification, int performanceIndex)
    {
        super( name,  teacherID, address, workingType, status);
        super.setWorkingHours(workingHours);
        this.salary = salary;
        this.specialization = specialization;
        this.academicQualification = academicQualification;
        this.performanceIndex = performanceIndex;
        this.isCertified = false;
    }
  


    
    
       /** Using accessor methods (get method) to retrive the value of salary.
       * 
       */      
    public double getsalary()
    {
        return this.salary;
    }
    
    
    
       /** Using accessor methods (get method) to retrive the value of specialization.
       * 
       */  
    public String getspecialization()
    {
        return this.specialization;
    }
    
    
    
       /** Using accessor methods (get method) to retrive the value of academicQualification.
       * 
       */  
    public String getAcademicQualification()
    {
       return academicQualification;
    }
    
    
    
       /** Using accessor methods (get method) to retrive the value of performanceIndex.
       * 
       */  
    public int getPerformance()
    {
        return performanceIndex;
    }
    
    
    
       /** Using accessor methods (get method) to retrive the value of isCertified.
       * 
       */      
    public boolean getIsCertified()
    {
        return isCertified;
    }

       
       /**Using set method to set a new value through a parameter
         * 
         */  
       public void setSalary(double salary, int newPerformanceIndex)
       {
          
           if(newPerformanceIndex > 5 && super.getworkingHours() > 20){
            
                if (newPerformanceIndex >= 5 && newPerformanceIndex <= 7){
                this.salary= salary + (5/100f)*this.salary;
                this.isCertified = true;
               }

               else if (newPerformanceIndex >= 8 && newPerformanceIndex <= 9){
               this.salary= salary + (10/100f)*this.salary;
               this.isCertified = true;

              }

               else if (newPerformanceIndex == 10){
                this.salary= salary + (20/100f)*this.salary;
                this.isCertified = true;

               }

               else{
                 System.out.println("Invalid performance index. Salary cannot be approved.");
                
               }

           }
        
           else{
            System.out.println("Performance index or working hours do not meet the requirements.Salary cannot be approved.");
           }
                 
        }
       
      
        /** this method helps to remove the tutor if he is not certified
       * 
       */
       public void removeTutor()
       {
           if(isCertified=true){
            this.salary = 0;
            this.specialization = "";
            this.academicQualification = "";
            this.performanceIndex = 0;
            
            this.isCertified = false;
           }
            else{
                System.out.println("Teacher is already certified.");
           }
            
       }

       public void Display()
       {
           if(!isCertified){
           super.Display();
         }
         else{
           super.Display();
             System.out.println("Salary: " + this.salary);
            System.out.println();
         }

        
      }
}