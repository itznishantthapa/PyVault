let boxes = document.querySelectorAll(".boxes");
console.log(boxes);
var counting = 0;
let winnerScripts = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [6, 4, 2]
];
// to make a turn alternate
let turnX = true;

boxes.forEach((box) => {
    box.addEventListener("click", () => {
        console.log("box was clicked");
        if (turnX) {
            // box.innerText = "X";
           
            counting = counting + 1;
            box.style.backgroundColor = "purple";
            // box.style.visibility = "hidden";
            turnX = false;


        }
        else {
            // box.innerText = "O";
           
            counting = counting + 1;
            box.style.backgroundColor = "green";
            // box.style.visibility = "hidden";
            turnX = true;

        }
        box.disabled = true;
        rematch();
        checkForWinner();

    });
});

const checkForWinner = () => {
    for (let winPattern of winnerScripts) {

        console.log(winPattern[0], winPattern[1], winPattern[2]);

        const pattern1 = boxes[winPattern[0]].style.backgroundColor
        const pattern2 = boxes[winPattern[1]].style.backgroundColor
        const pattern3 = boxes[winPattern[2]].style.backgroundColor


        if (pattern1 != "" && pattern2 != "" && pattern3 != "") {
            if (pattern1 == "purple" && pattern2 == "purple" && pattern3 == "purple" || pattern1 == "green" && pattern2 == "green" && pattern3 == "green") {
                console.log("winner is " + pattern1);
                document.querySelector(".para2").innerText = `Player ${pattern1}, You won the game`;
               
                PopUp();
                newGame();
                closeDialog();
                return;

            }
            if (counting == 9) {
                document.querySelector(".para2").innerText = `Player ${pattern1}, You defended well`;
                PopUp();
                newGame();
                closeDialog();
            }


        }

    }

}



const PopUp = () => {
    document.getElementById("overlay").style.display = "flex";
}

const newGame = () => {
    document.getElementById("newGame-btn").addEventListener("click", () => {
        // iterating over a NodeList to access each box
        boxes.forEach((box) => {
            box.style.backgroundColor = "white";
            box.disabled = false;
            box.style.pointerEvents = "auto";
            box.style.visibility = "visible";
        });
        turnX = false;
        document.getElementById("overlay").style.display = "none";
        counting = 0;
       


    });
}

const closeDialog = () => {

    document.getElementById("C-btn").addEventListener("click", () => {
        boxes.forEach((box) => {
            box.style.pointerEvents = "none";
        });
        document.getElementById("overlay").style.display = "none";
    });

}

const rematch = () => {
    document.getElementById("re-match").addEventListener("click", () => {
        // iterating over a NodeList to access each box
        boxes.forEach((box) => {
            box.style.backgroundColor = "white";
            box.disabled = false;
            box.style.pointerEvents = "auto";
            box.style.visibility = "visible";
        });
     
        turnX = false;
        counting = 0;
        // document.querySelector(".para2").innerText="";

    });
}
